package com.devdaljeet.grademanagementsystem.beans;

import lombok.*;

/** Represents the overall class average of a class.
 * (Note: lombok used for constructors, getters and setters)
 * @author Daljeet Singh (Dev-Daljeet)
 * @version 1.0
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class OverallClassAverage {
	
	private double avgExercises;
	public double getAvgExercises() {
		return avgExercises;
	}
	public void setAvgExercises(double avgExercises) {
		this.avgExercises = avgExercises;
	}
	public double getAvgAssignment1() {
		return avgAssignment1;
	}
	public void setAvgAssignment1(double avgAssignment1) {
		this.avgAssignment1 = avgAssignment1;
	}
	public double getAvgAssignment2() {
		return avgAssignment2;
	}
	public void setAvgAssignment2(double avgAssignment2) {
		this.avgAssignment2 = avgAssignment2;
	}
	public double getAvgAssignment3() {
		return avgAssignment3;
	}
	public void setAvgAssignment3(double avgAssignment3) {
		this.avgAssignment3 = avgAssignment3;
	}
	public double getAvgMidterm() {
		return avgMidterm;
	}
	public void setAvgMidterm(double avgMidterm) {
		this.avgMidterm = avgMidterm;
	}
	public double getAvgFinalExam() {
		return avgFinalExam;
	}
	public void setAvgFinalExam(double avgFinalExam) {
		this.avgFinalExam = avgFinalExam;
	}
	public double getOverallAverageGrade() {
		return overallAverageGrade;
	}
	public void setOverallAverageGrade(double overallAverageGrade) {
		this.overallAverageGrade = overallAverageGrade;
	}
	private double avgAssignment1;
	private double avgAssignment2;
	private double avgAssignment3;
	private double avgMidterm;
	private double avgFinalExam;
	private double overallAverageGrade;

}
